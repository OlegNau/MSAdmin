import { Component } from '@angular/core';

@Component({
  selector: 'app-repositories-list-skeleton',
  standalone: false,
  templateUrl: './repositories-list-skeleton.component.html',
  styleUrl: './repositories-list-skeleton.component.scss',
})
export class RepositoriesListSkeletonComponent {
}

export enum ViewState {
  Loading = 'loading',
  Empty = 'empty',
  Loaded = 'loaded',
  Error = 'error',
}
